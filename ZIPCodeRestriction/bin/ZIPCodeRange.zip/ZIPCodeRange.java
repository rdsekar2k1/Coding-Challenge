import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;


public class ZIPCodeRange {

	public static void main(String[] args) {
		
		Pattern pattern = Pattern.compile("^[0-9][0-9][0-9][0-9][0-9]"); // to validate the 5 digits number
		if(args.length>0){
			if(!pattern.matcher(args[0]).matches()){
				System.out.println("Invalid ZIP code argument. Sample format 12345");
				System.exit(0);// Added this line to exit the program if argument is not valid.
			}
		}
		
		String line;
		BufferedReader br = null;
		Map<Integer, Integer> zipCodeMap = new TreeMap<Integer, Integer>();
		String[] tempStr = null;
		int lowerBound = 0, upperBound = 0;
		try {
			
			br = new BufferedReader(new InputStreamReader(ZIPCodeRange.class.getResourceAsStream("input.txt"))); // Read the inputs from the text file
			
			int row = 0;
			while ((line = br.readLine()) != null) {
			  row++;
			  if(line==null || line.trim().length()==0) continue; // Continue to next line if the current line has no value
			  line = line.replace(" ", "");
			  tempStr = line.replace("[", "").replace("]", "").split(","); // Split the range into lower and upper values separately
			  // If the ZIP code range format is incorrect, throw the error message
			  if(!line.startsWith("[") || !line.endsWith("]") || line.indexOf(",")<0 || tempStr.length!=2){
				  throw new IllegalArgumentException("Invaid Zip code range format in Row No: "+row+" in the input file. Sample format [10000,99999]");
			  }
			  // If lower or upper range is not in 5 digits format, throw the error message
			  if(!pattern.matcher(tempStr[0]).matches() || !pattern.matcher(tempStr[1]).matches()){
				  throw new IllegalArgumentException("Invaid Zip code range in Row No: "+row+" in the input file. Sample format [10000,99999]");
			  }
			  lowerBound = Integer.parseInt(tempStr[0]);
			  upperBound = Integer.parseInt(tempStr[1]);
			  
			  //Swap lower and upper bounds if lower bound value is greater than upper bound value
			  ZIPCodeRange.swap(zipCodeMap, lowerBound, upperBound);
			  
			}
			
			if(zipCodeMap.size()==0){
				System.out.println("No data found in the input file to exclude. So all ZIP codes are valid");
			}else if(zipCodeMap.size()>1){
				ZIPCodeRange.merge(zipCodeMap);
			}

			// Printing excluded ZIP codes
			if(zipCodeMap.size()>0){
				System.out.println("ZIP code ranges excluded...");
			}
			for(Map.Entry<Integer, Integer> excludedZip:zipCodeMap.entrySet()){
				System.out.print("["+ ("00000" + excludedZip.getKey()).substring(excludedZip.getKey().toString().length())+","+("00000" + excludedZip.getValue()).substring(excludedZip.getValue().toString().length())+"] ");
			}
			
			if(args.length>0 && args[0]!=null){
				int inputZipCode = Integer.parseInt(args[0]);
				if(!ZIPCodeRange.isValidZip(zipCodeMap, inputZipCode)){
					System.out.println("\nItem cannot be shipped to "+args[0]);
				}else{
					System.out.println("\nItem can be shipped to "+args[0]);
				}
			}
			
		} catch(IllegalArgumentException argex){
			System.out.println(argex.getMessage());
		}catch (Exception e) {
			// Just for testing, added these lines
			if(br==null){
				System.out.println("Input File not found"); // if input file not exists, buffered reader would be null
			}else{
				e.printStackTrace(); 
			}
		} finally{
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
	}
	
	/**
	 * This method is used to create the input values in TreeMap object as key value pair and its sorted by key automatically
	 * @param zipCodeMap - TreeMap object used to keep all the ZIP code ranges 
	 * @param lowerBound - Lower Range
	 * @param upperBound - Upper Range
	 * @return zipCodeMap after swapping the lower ad upper bound range
	 */
	private static Map<Integer, Integer> swap(Map<Integer, Integer> zipCodeMap, Integer lowerBound, Integer upperBound){
		
		if(lowerBound>upperBound){
			  if(zipCodeMap.containsKey(upperBound)){
				  if(zipCodeMap.get(upperBound)<lowerBound){
					  zipCodeMap.put(upperBound, lowerBound);
				  }
			  }else{
				  zipCodeMap.put(upperBound, lowerBound);  
			  }
		  }else{
			  if(zipCodeMap.containsKey(lowerBound)){
				  if(zipCodeMap.get(lowerBound)<upperBound){
					  zipCodeMap.put(lowerBound, upperBound);
				  }
			  }else{
				  zipCodeMap.put(lowerBound, upperBound);  
			  }
		  }
		return zipCodeMap;
	}
	
	
	/**
	 * This method is used to merge all the ZIP code ranges
	 * @param zipCodeMap - TreeMap object hold all the ZIP code range values
	 * @return zipCodeMap after merged.
	 */
	private static Map<Integer, Integer> merge(Map<Integer, Integer> zipCodeMap){
		List<Integer> list = new ArrayList<Integer>(zipCodeMap.keySet());
		for(int i=0;i<list.size();i++){
			if(zipCodeMap.get(list.get(i))==null) continue;
			for(int j=i+1;j<list.size();j++){
				if(zipCodeMap.get(list.get(j))==null) continue;
				if(zipCodeMap.get(list.get(i))==null) continue;
				if(zipCodeMap.get(list.get(i))==list.get(j) || zipCodeMap.get(list.get(i))-list.get(j)==-1){
					zipCodeMap.put(list.get(i), zipCodeMap.get(list.get(j)));
					zipCodeMap.remove(list.get(j));
				}else if(list.get(i)<=list.get(j) && list.get(j)<=zipCodeMap.get(list.get(i)) && list.get(i)<=zipCodeMap.get(list.get(j)) && zipCodeMap.get(list.get(j))<=zipCodeMap.get(list.get(i)) ){
					zipCodeMap.remove(list.get(j));
				}else if(list.get(i)<=list.get(j) && list.get(j)<=zipCodeMap.get(list.get(i)) && list.get(i)<=zipCodeMap.get(list.get(j)) && zipCodeMap.get(list.get(j))>=zipCodeMap.get(list.get(i)) ){
					zipCodeMap.put(list.get(i), zipCodeMap.get(list.get(j)));
					zipCodeMap.remove(list.get(j));
				}
				
			}
		}
		return zipCodeMap;
	}
	
	/**
	 * this method is used to identify whether ZIP code is valid or not
	 * @param excludedZipRange - has ZIP code ranges after compressed
	 * @param inputZipCode - user input ZIP code
	 * @return false if ZIP code not valid otherwise true
	 */
	private static boolean isValidZip(Map<Integer, Integer> excludedZipRange, int inputZipCode){
		boolean validZip = true;
		for(Map.Entry<Integer, Integer> excludedZip:excludedZipRange.entrySet()){
			if(excludedZip.getKey()<=inputZipCode && inputZipCode<=excludedZip.getValue()){
				validZip = false;
				break;
			}
		}
		return validZip;
	}

}
