'use strict';
var productApp = angular.module('productApp', ['productApp.controllers']);