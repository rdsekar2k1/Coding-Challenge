This is the sample web application built in AngularJS framework

How to use?

1) Deploy the war file in web server and access the below URL. Use the appropriate port number which used in your web server setting

http://localhost:8080/ProductsWeb/products.html

As per the requirement, this web page built to support both desktop and mobile view.

Desktop view - it display 3 products each row
Mobile view - it displays 1 product each row